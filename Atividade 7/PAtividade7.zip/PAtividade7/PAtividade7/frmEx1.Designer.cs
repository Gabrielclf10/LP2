﻿
namespace PAtividade7
{
    partial class frmEx1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchbox1 = new System.Windows.Forms.RichTextBox();
            this.lblEx1 = new System.Windows.Forms.Label();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnLetraDupla = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchbox1
            // 
            this.rchbox1.Location = new System.Drawing.Point(36, 80);
            this.rchbox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rchbox1.Name = "rchbox1";
            this.rchbox1.Size = new System.Drawing.Size(248, 422);
            this.rchbox1.TabIndex = 0;
            this.rchbox1.Text = "";
            // 
            // lblEx1
            // 
            this.lblEx1.AutoSize = true;
            this.lblEx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEx1.Location = new System.Drawing.Point(36, 30);
            this.lblEx1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEx1.Name = "lblEx1";
            this.lblEx1.Size = new System.Drawing.Size(131, 29);
            this.lblEx1.TabIndex = 1;
            this.lblEx1.Text = "Exercício 1";
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(338, 80);
            this.btnBranco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(141, 84);
            this.btnBranco.TabIndex = 2;
            this.btnBranco.Text = "Número de espaços em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(338, 164);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(141, 84);
            this.btnLetraR.TabIndex = 3;
            this.btnLetraR.Text = "Número de Letras R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnLetraDupla
            // 
            this.btnLetraDupla.Location = new System.Drawing.Point(338, 247);
            this.btnLetraDupla.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLetraDupla.Name = "btnLetraDupla";
            this.btnLetraDupla.Size = new System.Drawing.Size(141, 84);
            this.btnLetraDupla.TabIndex = 4;
            this.btnLetraDupla.Text = "Número de letras casadas";
            this.btnLetraDupla.UseVisualStyleBackColor = true;
            this.btnLetraDupla.Click += new System.EventHandler(this.btnLetraDupla_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(338, 425);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(141, 39);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(338, 471);
            this.btnSair.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(141, 32);
            this.btnSair.TabIndex = 6;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // frmEx1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 554);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnLetraDupla);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.lblEx1);
            this.Controls.Add(this.rchbox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmEx1";
            this.Text = "frmEx1";
            this.Load += new System.EventHandler(this.frmEx1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchbox1;
        private System.Windows.Forms.Label lblEx1;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnLetraDupla;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}