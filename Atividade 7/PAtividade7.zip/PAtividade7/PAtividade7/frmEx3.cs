﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmEx3 : Form
    {
        public frmEx3()
        {
            InitializeComponent();
        }

        private void frmEx3_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtTexto.Clear();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string Texto = txtTexto.Text;


            if (Texto.Length > 50)
            {
                MessageBox.Show("Não dece ser maior do que 50 Caracteres!");
            }
            else
            {
                Texto = Texto.Replace(" ", String.Empty);
            
                string aux = "";

                for (int i = Texto.Length; i != 0; i--)
                {
                      aux = aux + char.ToUpper(Texto[i-1]);
                
                }
             
                if (string.Equals(aux,Texto.ToUpper()))
                {
                    MessageBox.Show(aux +" é um palindromo. ");
                }
               else
               {
                   MessageBox.Show(aux + " não é um palindormo. ");

               }
            }
            
            
            
        }

    }
}
