﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmEx2 : Form
    {
        public frmEx2()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtboxNum.Clear();
            txtboxNum.Focus();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            double N;
            double H=1;
            double i;

            if (double.TryParse(txtboxNum.Text, out N))
            {
                if (N > 0)
                {
                    for (i = 2; i <= N; i++)
                    {
                        H = H+(1/i);
                       
                    }
                    MessageBox.Show(H.ToString());
                }
                else 
                { 
                    MessageBox.Show("Deve ser maior do que 0", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Apenas letras", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
