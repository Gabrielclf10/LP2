﻿
namespace PAtividade7
{
    partial class frmEx4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.txtNumeroIncricao = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtGratificacao = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblNumeroInscricao = new System.Windows.Forms.Label();
            this.lblProducao = new System.Windows.Forms.Label();
            this.blbSalario = new System.Windows.Forms.Label();
            this.lblGratificacao = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblEx4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(129, 121);
            this.txtNome.Margin = new System.Windows.Forms.Padding(6);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(438, 29);
            this.txtNome.TabIndex = 0;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(129, 186);
            this.txtCargo.Margin = new System.Windows.Forms.Padding(6);
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.Size = new System.Drawing.Size(244, 29);
            this.txtCargo.TabIndex = 1;
            // 
            // txtNumeroIncricao
            // 
            this.txtNumeroIncricao.Location = new System.Drawing.Point(231, 251);
            this.txtNumeroIncricao.Margin = new System.Windows.Forms.Padding(6);
            this.txtNumeroIncricao.Name = "txtNumeroIncricao";
            this.txtNumeroIncricao.Size = new System.Drawing.Size(142, 29);
            this.txtNumeroIncricao.TabIndex = 2;
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(231, 316);
            this.txtProducao.Margin = new System.Windows.Forms.Padding(6);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(142, 29);
            this.txtProducao.TabIndex = 3;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(502, 246);
            this.txtSalario.Margin = new System.Windows.Forms.Padding(6);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(142, 29);
            this.txtSalario.TabIndex = 4;
            // 
            // txtGratificacao
            // 
            this.txtGratificacao.Location = new System.Drawing.Point(502, 311);
            this.txtGratificacao.Margin = new System.Windows.Forms.Padding(6);
            this.txtGratificacao.Name = "txtGratificacao";
            this.txtGratificacao.Size = new System.Drawing.Size(142, 29);
            this.txtGratificacao.TabIndex = 5;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(28, 124);
            this.lblNome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(67, 24);
            this.lblNome.TabIndex = 6;
            this.lblNome.Text = "Nome:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 189);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 24);
            this.label2.TabIndex = 7;
            this.label2.Text = "Cargo:";
            // 
            // lblNumeroInscricao
            // 
            this.lblNumeroInscricao.AutoSize = true;
            this.lblNumeroInscricao.Location = new System.Drawing.Point(28, 254);
            this.lblNumeroInscricao.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblNumeroInscricao.Name = "lblNumeroInscricao";
            this.lblNumeroInscricao.Size = new System.Drawing.Size(191, 24);
            this.lblNumeroInscricao.TabIndex = 8;
            this.lblNumeroInscricao.Text = "Número de Inscrição:";
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.Location = new System.Drawing.Point(28, 319);
            this.lblProducao.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(97, 24);
            this.lblProducao.TabIndex = 9;
            this.lblProducao.Text = "Produção:";
            // 
            // blbSalario
            // 
            this.blbSalario.AutoSize = true;
            this.blbSalario.Location = new System.Drawing.Point(385, 251);
            this.blbSalario.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.blbSalario.Name = "blbSalario";
            this.blbSalario.Size = new System.Drawing.Size(72, 24);
            this.blbSalario.TabIndex = 10;
            this.blbSalario.Text = "Salário:";
            // 
            // lblGratificacao
            // 
            this.lblGratificacao.AutoSize = true;
            this.lblGratificacao.Location = new System.Drawing.Point(385, 316);
            this.lblGratificacao.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblGratificacao.Name = "lblGratificacao";
            this.lblGratificacao.Size = new System.Drawing.Size(112, 24);
            this.lblGratificacao.TabIndex = 11;
            this.lblGratificacao.Text = "Gratificação:";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(49, 425);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(351, 40);
            this.btnCalc.TabIndex = 12;
            this.btnCalc.Text = "Cálcular Salário Bruto";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(415, 425);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(120, 40);
            this.btnLimpar.TabIndex = 13;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(541, 425);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(120, 40);
            this.btnSair.TabIndex = 14;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblEx4
            // 
            this.lblEx4.AutoSize = true;
            this.lblEx4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEx4.Location = new System.Drawing.Point(27, 50);
            this.lblEx4.Name = "lblEx4";
            this.lblEx4.Size = new System.Drawing.Size(131, 29);
            this.lblEx4.TabIndex = 15;
            this.lblEx4.Text = "Exercício 4";
            // 
            // frmEx4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 521);
            this.Controls.Add(this.lblEx4);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblGratificacao);
            this.Controls.Add(this.blbSalario);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.lblNumeroInscricao);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtGratificacao);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtNumeroIncricao);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.txtNome);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmEx4";
            this.Text = "frmEx4";
            this.Load += new System.EventHandler(this.frmEx4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtCargo;
        private System.Windows.Forms.TextBox txtNumeroIncricao;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtGratificacao;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblNumeroInscricao;
        private System.Windows.Forms.Label lblProducao;
        private System.Windows.Forms.Label blbSalario;
        private System.Windows.Forms.Label lblGratificacao;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblEx4;
    }
}