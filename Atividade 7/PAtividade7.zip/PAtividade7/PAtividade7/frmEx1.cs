﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void frmEx1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchbox1.Clear();
            rchbox1.Focus();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int i = 0, qnt = 0;
            int x = rchbox1.Text.Length;
            

            while (i < x)
            {
                if (rchbox1.Text[i] == ' ')
                    qnt++;

                i++;
            }

            MessageBox.Show( qnt.ToString() + " espaços em branco.");


        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int i = 0,x= rchbox1.Text.Length, qnt=0;

            for (i = 0; i < x; i++)
            {
                if (rchbox1.Text[i] == 'r' || (rchbox1.Text[i] == 'R' ))
                    qnt++;
            }

            MessageBox.Show(qnt.ToString() + " letras R.");

        }

        private void btnLetraDupla_Click(object sender, EventArgs e)
        {
            int i = 0, x = rchbox1.Text.Length, qnt = 0;

            for (i = 0; i < x-1 ; i++)
            {
                
                if (rchbox1.Text[i] == (rchbox1.Text[i+1]))
                    qnt++;
            }

            MessageBox.Show(qnt.ToString() + "  par(es) de letras.");

        }
    }
}

