﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void frmEx4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double Bruto;
            double Salario;
            double Gratificacao;
            float Producao;
            int numInscricao,B=0,C=0,D=0;

            if (double.TryParse(txtSalario.Text, out Salario) && (int.TryParse(txtNumeroIncricao.Text, out numInscricao)) &&
                (double.TryParse(txtGratificacao.Text, out Gratificacao)) && (float.TryParse(txtProducao.Text, out Producao)))
            {
                if (Producao >= 100)
                {
                    B = 1;
                }
                else if (Producao >= 120)
                {
                    C = 1;
                }
                else if (Producao >= 150)
                {
                    D = 1;
                }

                Bruto = Salario + Salario * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;

                if ((Bruto > 7000) && (Producao < 150) && (Gratificacao < 0.1))
                {
                    Bruto = 7000;
                }

                MessageBox.Show("O Salário Bruto de "+ txtNome.Text +" é: R$ "+ Bruto.ToString("N2"),"Cálculo",MessageBoxButtons.OK, MessageBoxIcon.Information);


            }

            else
            {
                MessageBox.Show("Preencha os campos corretamente","Aviso",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCargo.Clear();
            txtGratificacao.Clear();
            txtNome.Clear();
            txtNumeroIncricao.Clear();
            txtProducao.Clear();
            txtSalario.Clear();
            txtNome.Focus();

        }
    }
}
