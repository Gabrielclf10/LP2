﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ex1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx1>().Count() > 0)
            {
                MessageBox.Show("Já está aberto");

            }
            else
            {
                frmEx1 objFrm = new frmEx1();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void ex2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx2>().Count() > 0)
            {
                MessageBox.Show("Já está aberto");

            }
            else
            {
                frmEx2 objFrm = new frmEx2();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void ex3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx3>().Count() > 0)
            {
                MessageBox.Show("Já está aberto");

            }
            else
            {
                frmEx3 objFrm = new frmEx3();
                objFrm.MdiParent = this;
                objFrm.WindowState = FormWindowState.Maximized;
                objFrm.Show();
            }
        }

        private void ex4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fc = Application.OpenForms["frmEx4"];

            if (fc != null)
                fc.Close();

            frmEx4 frm2 = new frmEx4();// criando objeto
            frm2.MdiParent = this;
            frm2.WindowState = FormWindowState.Maximized;
            frm2.Show();
        }
    }
}

