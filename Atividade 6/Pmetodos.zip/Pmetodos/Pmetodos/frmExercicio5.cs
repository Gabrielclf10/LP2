﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {

            Random sorteio = new Random(); //classe Random ja existe, entao chama e cria obj chamado sorteio

           
            int num1;
            int num2;

            if (int.TryParse(txtNum1.Text, out num1) && int.TryParse(txtNum2.Text, out num2))
            {
                int i = 0;
                if (num1 > num2)
                    i = sorteio.Next(num2, num1);
                else if (num2 > num1)
                    i = sorteio.Next(num1, num2);

                MessageBox.Show("Numero sorteado: " + i.ToString(), "Sorteio", MessageBoxButtons.OK, MessageBoxIcon.Information); ;

            }
            else
            {
                MessageBox.Show("Insira apenas numeros","Aviso",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();

            txtNum1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
