﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            int i, cont=0;

            for ( i=0; i<rctboxTexto.Text.Length; i++)
                if (char.IsNumber(rctboxTexto.Text, i)== true)
                {
                    cont++;
                }

            MessageBox.Show("Quantidade de numeros: " + cont);


        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            int cont = 0;

            //for (int i = 0; i < rctboxTexto.Text.Length; i++)
            //    if (char.IsLetter(rctboxTexto.Text, i) == true)
            //    {
            //        cont++;
            //    }

            foreach (char letra in rctboxTexto.Text)
            {
                if (char.IsLetter(letra))
                    cont++;
            }



            MessageBox.Show("Quantidade de alfabéticos: " + cont);



        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int i=0;

            if (rctboxTexto.Text.Length>0)
                while (i < rctboxTexto.Text.Length)
                {
                    if ((char.IsWhiteSpace(rctboxTexto.Text, i)))
                    {
                        MessageBox.Show("Indice: "+ i, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                    if (i == rctboxTexto.Text.Length - 1)
                    {
                        MessageBox.Show("Não existe espaço em branco","Aviso",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }

                    i++;

                }
           
            else
            {
                MessageBox.Show("Digite algo", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rctboxTexto.Clear();
            rctboxTexto.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
