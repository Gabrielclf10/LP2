﻿
namespace PSalario
{
    partial class form
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnome = new System.Windows.Forms.Label();
            this.lblSalariobruto = new System.Windows.Forms.Label();
            this.lblNumeroFilhos = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rdbtnFem = new System.Windows.Forms.RadioButton();
            this.rdbtnMasc = new System.Windows.Forms.RadioButton();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.mskbxSalariobruto = new System.Windows.Forms.MaskedTextBox();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtAliquotaIR = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIR = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIR = new System.Windows.Forms.Label();
            this.txtDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtDescontoIR = new System.Windows.Forms.TextBox();
            this.bntLimpar = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cbbxNumeroFilhos = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbxSexo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(14, 71);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(135, 16);
            this.lblnome.TabIndex = 0;
            this.lblnome.Text = "Nome do Funcionário:";
            // 
            // lblSalariobruto
            // 
            this.lblSalariobruto.AutoSize = true;
            this.lblSalariobruto.Location = new System.Drawing.Point(14, 108);
            this.lblSalariobruto.Name = "lblSalariobruto";
            this.lblSalariobruto.Size = new System.Drawing.Size(87, 16);
            this.lblSalariobruto.TabIndex = 1;
            this.lblSalariobruto.Text = "Salário Bruto:";
            // 
            // lblNumeroFilhos
            // 
            this.lblNumeroFilhos.AutoSize = true;
            this.lblNumeroFilhos.Location = new System.Drawing.Point(14, 145);
            this.lblNumeroFilhos.Name = "lblNumeroFilhos";
            this.lblNumeroFilhos.Size = new System.Drawing.Size(114, 16);
            this.lblNumeroFilhos.TabIndex = 2;
            this.lblNumeroFilhos.Text = "Número de Filhos:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(161, 68);
            this.txtNome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(264, 22);
            this.txtNome.TabIndex = 5;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rdbtnFem);
            this.gbxSexo.Controls.Add(this.rdbtnMasc);
            this.gbxSexo.Location = new System.Drawing.Point(452, 63);
            this.gbxSexo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gbxSexo.Size = new System.Drawing.Size(69, 98);
            this.gbxSexo.TabIndex = 6;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rdbtnFem
            // 
            this.rdbtnFem.AutoSize = true;
            this.rdbtnFem.Location = new System.Drawing.Point(22, 54);
            this.rdbtnFem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdbtnFem.Name = "rdbtnFem";
            this.rdbtnFem.Size = new System.Drawing.Size(34, 20);
            this.rdbtnFem.TabIndex = 1;
            this.rdbtnFem.Text = "F";
            this.rdbtnFem.UseVisualStyleBackColor = true;
            this.rdbtnFem.CheckedChanged += new System.EventHandler(this.rdbtnFem_CheckedChanged);
            // 
            // rdbtnMasc
            // 
            this.rdbtnMasc.AutoSize = true;
            this.rdbtnMasc.Checked = true;
            this.rdbtnMasc.Location = new System.Drawing.Point(22, 26);
            this.rdbtnMasc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdbtnMasc.Name = "rdbtnMasc";
            this.rdbtnMasc.Size = new System.Drawing.Size(37, 20);
            this.rdbtnMasc.TabIndex = 0;
            this.rdbtnMasc.TabStop = true;
            this.rdbtnMasc.Text = "M";
            this.rdbtnMasc.UseVisualStyleBackColor = true;
            this.rdbtnMasc.CheckedChanged += new System.EventHandler(this.rdbtnMasc_CheckedChanged);
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(336, 104);
            this.ckbxCasado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(71, 20);
            this.ckbxCasado.TabIndex = 7;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            this.ckbxCasado.CheckedChanged += new System.EventHandler(this.ckbxCasado_CheckedChanged);
            // 
            // mskbxSalariobruto
            // 
            this.mskbxSalariobruto.Location = new System.Drawing.Point(161, 106);
            this.mskbxSalariobruto.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mskbxSalariobruto.Mask = "00000.00";
            this.mskbxSalariobruto.Name = "mskbxSalariobruto";
            this.mskbxSalariobruto.Size = new System.Drawing.Size(98, 22);
            this.mskbxSalariobruto.TabIndex = 8;
            this.mskbxSalariobruto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskbxSalariobruto_KeyPress);
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.BackColor = System.Drawing.SystemColors.Menu;
            this.lblMensagem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMensagem.Location = new System.Drawing.Point(14, 253);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(44, 18);
            this.lblMensagem.TabIndex = 9;
            this.lblMensagem.Text = "label1";
            this.lblMensagem.Visible = false;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(77, 188);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(205, 52);
            this.btnVerificar.TabIndex = 10;
            this.btnVerificar.Text = "Verificar descontos";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Enabled = false;
            this.txtAliquotaINSS.Location = new System.Drawing.Point(143, 336);
            this.txtAliquotaINSS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(116, 22);
            this.txtAliquotaINSS.TabIndex = 11;
            // 
            // txtAliquotaIR
            // 
            this.txtAliquotaIR.Enabled = false;
            this.txtAliquotaIR.Location = new System.Drawing.Point(143, 368);
            this.txtAliquotaIR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAliquotaIR.Name = "txtAliquotaIR";
            this.txtAliquotaIR.Size = new System.Drawing.Size(116, 22);
            this.txtAliquotaIR.TabIndex = 12;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Enabled = false;
            this.txtSalarioFamilia.Location = new System.Drawing.Point(143, 400);
            this.txtSalarioFamilia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(116, 22);
            this.txtSalarioFamilia.TabIndex = 13;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Enabled = false;
            this.txtSalarioLiquido.Location = new System.Drawing.Point(143, 432);
            this.txtSalarioLiquido.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.Size = new System.Drawing.Size(116, 22);
            this.txtSalarioLiquido.TabIndex = 14;
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(40, 340);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(93, 16);
            this.lblAliquotaINSS.TabIndex = 15;
            this.lblAliquotaINSS.Text = "Aliquota INSS:";
            // 
            // lblAliquotaIR
            // 
            this.lblAliquotaIR.AutoSize = true;
            this.lblAliquotaIR.Location = new System.Drawing.Point(40, 372);
            this.lblAliquotaIR.Name = "lblAliquotaIR";
            this.lblAliquotaIR.Size = new System.Drawing.Size(75, 16);
            this.lblAliquotaIR.TabIndex = 16;
            this.lblAliquotaIR.Text = "Aliquota IR:";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(40, 404);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(98, 16);
            this.lblSalarioFamilia.TabIndex = 17;
            this.lblSalarioFamilia.Text = "Salario Familia:";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(40, 436);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(97, 16);
            this.lblSalarioLiquido.TabIndex = 18;
            this.lblSalarioLiquido.Text = "Salario Liquido:";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Location = new System.Drawing.Point(284, 340);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(101, 16);
            this.lblDescontoINSS.TabIndex = 19;
            this.lblDescontoINSS.Text = "Desconto INSS:";
            // 
            // lblDescontoIR
            // 
            this.lblDescontoIR.AutoSize = true;
            this.lblDescontoIR.Location = new System.Drawing.Point(284, 372);
            this.lblDescontoIR.Name = "lblDescontoIR";
            this.lblDescontoIR.Size = new System.Drawing.Size(83, 16);
            this.lblDescontoIR.TabIndex = 20;
            this.lblDescontoIR.Text = "Desconto IR:";
            // 
            // txtDescontoINSS
            // 
            this.txtDescontoINSS.Enabled = false;
            this.txtDescontoINSS.Location = new System.Drawing.Point(391, 336);
            this.txtDescontoINSS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDescontoINSS.Name = "txtDescontoINSS";
            this.txtDescontoINSS.Size = new System.Drawing.Size(116, 22);
            this.txtDescontoINSS.TabIndex = 21;
            // 
            // txtDescontoIR
            // 
            this.txtDescontoIR.Enabled = false;
            this.txtDescontoIR.Location = new System.Drawing.Point(391, 369);
            this.txtDescontoIR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDescontoIR.Name = "txtDescontoIR";
            this.txtDescontoIR.Size = new System.Drawing.Size(116, 22);
            this.txtDescontoIR.TabIndex = 22;
            // 
            // bntLimpar
            // 
            this.bntLimpar.Location = new System.Drawing.Point(336, 188);
            this.bntLimpar.Name = "bntLimpar";
            this.bntLimpar.Size = new System.Drawing.Size(130, 52);
            this.bntLimpar.TabIndex = 23;
            this.bntLimpar.Text = "Limpar Dados";
            this.bntLimpar.UseVisualStyleBackColor = true;
            this.bntLimpar.Click += new System.EventHandler(this.bntLimpar_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(217, 477);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(126, 43);
            this.btnClose.TabIndex = 24;
            this.btnClose.Text = "Encerrar";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cbbxNumeroFilhos
            // 
            this.cbbxNumeroFilhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbxNumeroFilhos.FormattingEnabled = true;
            this.cbbxNumeroFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26"});
            this.cbbxNumeroFilhos.Location = new System.Drawing.Point(161, 142);
            this.cbbxNumeroFilhos.Name = "cbbxNumeroFilhos";
            this.cbbxNumeroFilhos.Size = new System.Drawing.Size(106, 24);
            this.cbbxNumeroFilhos.TabIndex = 25;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(547, 50);
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(17, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 24);
            this.label1.TabIndex = 27;
            this.label1.Text = "Cálculo do Salário Líquido";
            // 
            // form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(544, 554);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cbbxNumeroFilhos);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.bntLimpar);
            this.Controls.Add(this.txtDescontoIR);
            this.Controls.Add(this.txtDescontoINSS);
            this.Controls.Add(this.lblDescontoIR);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIR);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.txtSalarioLiquido);
            this.Controls.Add(this.txtSalarioFamilia);
            this.Controls.Add(this.txtAliquotaIR);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.mskbxSalariobruto);
            this.Controls.Add(this.ckbxCasado);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNumeroFilhos);
            this.Controls.Add(this.lblSalariobruto);
            this.Controls.Add(this.lblnome);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "form";
            this.Text = "Form1";
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblSalariobruto;
        private System.Windows.Forms.Label lblNumeroFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rdbtnFem;
        private System.Windows.Forms.RadioButton rdbtnMasc;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.MaskedTextBox mskbxSalariobruto;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtAliquotaIR;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.TextBox txtSalarioLiquido;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIR;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIR;
        private System.Windows.Forms.TextBox txtDescontoINSS;
        private System.Windows.Forms.TextBox txtDescontoIR;
        private System.Windows.Forms.Button bntLimpar;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cbbxNumeroFilhos;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}

