﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class form : Form
    {
        public form()
        {
            InitializeComponent();

            txtNome.Focus();

            cbbxNumeroFilhos.SelectedIndex = 0;
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lblMensagem.Visible = true;

            double descontoINSS = 0;
            double descontoIR = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;

            if ((txtNome.Text == "") || (txtNome.Text.Length < 2))
                MessageBox.Show("Nome inválido", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else if (double.TryParse(mskbxSalariobruto.Text, out salarioBruto))
            {
                //-------calculo de INSS--------
                if (salarioBruto <= 800.47)
                {
                    txtAliquotaINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                    txtDescontoINSS.Text = "R$ " + descontoINSS.ToString();
                }
                else if (salarioBruto < 1050)
                {
                    txtAliquotaINSS.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                    txtDescontoINSS.Text = "R$ " + descontoINSS.ToString();
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliquotaINSS.Text = "9.00%";
                    descontoINSS = 0.09 * salarioBruto;
                    txtDescontoINSS.Text = "R$ " + descontoINSS.ToString();
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliquotaINSS.Text = "11.00%";
                    descontoINSS = 0.11 * salarioBruto;
                    txtDescontoINSS.Text = "R$ " + descontoINSS.ToString();
                }
                else
                {
                    txtAliquotaINSS.Text = "Teto";
                    descontoINSS = 308.17;
                    txtDescontoINSS.Text = "R$ " + descontoINSS.ToString();
                }

                //--------calculo de IR---------
                if (salarioBruto >= 1257.13 && salarioBruto <= 2512.08)
                {
                    txtAliquotaIR.Text = "15.00%";
                    descontoIR = 0.15 * salarioBruto;
                    txtDescontoIR.Text = "R$ " + descontoIR.ToString();

                }
                else if (salarioBruto > 2515.08)
                {
                    txtAliquotaIR.Text = "27.5%";
                    descontoIR = 0.275 * salarioBruto;
                    txtDescontoIR.Text = "R$ " + descontoIR.ToString();
                }
                else
                {
                    txtAliquotaIR.Text = "Isento";
                    descontoIR = 0;
                    txtDescontoIR.Text = "R$ " + descontoIR.ToString();
                }

                //-------Salario Familia---------
                if (salarioBruto <= 435.52)
                {
                   for (int i = 0; i < cbbxNumeroFilhos.SelectedIndex; i++)
                    {
                        salarioFamilia = salarioFamilia + 22.33;
                    }
                    txtSalarioFamilia.Text = "R$ " + salarioFamilia.ToString();
                }

                else if (salarioBruto >= 435.53 && salarioBruto <= 654.61)
                {
                    for (int i = 0; i < cbbxNumeroFilhos.SelectedIndex; i++)
                    {
                        salarioFamilia = salarioFamilia + 15.74;
                    }
                    txtSalarioFamilia.Text = "R$ " + salarioFamilia.ToString();
                }

                else
                {
                    txtSalarioFamilia.Text = "R$ " + salarioFamilia.ToString();
                }


            }
            else
                MessageBox.Show("Salário Bruto inválido", "Aviso",MessageBoxButtons.OK, MessageBoxIcon.Error);

            //-----Salario Liquido---
            
            salarioLiquido = salarioBruto - descontoINSS - descontoIR + salarioFamilia;
            txtSalarioLiquido.Text = "R$ " + salarioLiquido.ToString();

            //------Mensagem-------

            lblMensagem.MaximumSize = new Size(500, 0);
            lblMensagem.AutoSize = true;

            lblMensagem.Text = "Os descontos do salário ";

            if (rdbtnMasc.Checked == true)
                lblMensagem.Text = lblMensagem.Text + "do ";
            else
                lblMensagem.Text = lblMensagem.Text + "da ";

            lblMensagem.Text = lblMensagem.Text + txtNome.Text + " que é ";

            if (ckbxCasado.Checked == true)
                lblMensagem.Text = lblMensagem.Text + "Casado(a) e que tem " ;
            else
                lblMensagem.Text = lblMensagem.Text + "Solteiro(a) e que tem ";

            lblMensagem.Text = lblMensagem.Text + cbbxNumeroFilhos.SelectedIndex.ToString() + " filho(s) são: ";

        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtAliquotaINSS.Clear();
            txtAliquotaIR.Clear();
            txtDescontoINSS.Clear();
            txtDescontoIR.Clear();
            txtSalarioFamilia.Clear();
            txtSalarioLiquido.Clear();
            mskbxSalariobruto.Clear();
            lblMensagem.Text = "";


            txtNome.Focus();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13) 
            {
                SendKeys.Send("{TAB}"); 
                e.Handled = true;   
            }
        }

        private void mskbxSalariobruto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void rdbtnMasc_CheckedChanged(object sender, EventArgs e)
        {


        }


        private void rdbtnFem_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void ckbxCasado_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
