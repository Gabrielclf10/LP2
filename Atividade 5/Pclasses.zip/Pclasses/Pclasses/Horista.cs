﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    class Horista : Empregado
    {
        // nao existe herança multipla
        //propriedades:  "prop TAB TAB"
        public double SalarioHora { get; set; }

        public double NumeroHora { get; set; }

        public int DiasFalta { get; set; }



        public override double SalarioBruto() // obrigado a fazer
        {
            return (SalarioHora * NumeroHora);
            throw new NotImplementedException();
        }


        //overide é sobreencrever


        public override int TempoTrabalho()
        {
            //representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            return(Convert.ToInt32(span.Days) - DiasFalta);
        }



    }
}
