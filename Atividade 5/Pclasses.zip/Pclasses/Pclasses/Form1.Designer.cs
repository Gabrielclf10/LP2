﻿
namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMensal = new System.Windows.Forms.Button();
            this.btnHoral = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMensal
            // 
            this.btnMensal.Location = new System.Drawing.Point(57, 56);
            this.btnMensal.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnMensal.Name = "btnMensal";
            this.btnMensal.Size = new System.Drawing.Size(156, 101);
            this.btnMensal.TabIndex = 0;
            this.btnMensal.Text = "Mensalista";
            this.btnMensal.UseVisualStyleBackColor = true;
            this.btnMensal.Click += new System.EventHandler(this.btnMensal_Click);
            // 
            // btnHoral
            // 
            this.btnHoral.Location = new System.Drawing.Point(240, 54);
            this.btnHoral.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.btnHoral.Name = "btnHoral";
            this.btnHoral.Size = new System.Drawing.Size(156, 101);
            this.btnHoral.TabIndex = 1;
            this.btnHoral.Text = "Horista";
            this.btnHoral.UseVisualStyleBackColor = true;
            this.btnHoral.Click += new System.EventHandler(this.btnHoral_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(335, 202);
            this.btnSair.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(61, 37);
            this.btnSair.TabIndex = 2;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 286);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnHoral);
            this.Controls.Add(this.btnMensal);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMensal;
        private System.Windows.Forms.Button btnHoral;
        private System.Windows.Forms.Button btnSair;
    }
}

