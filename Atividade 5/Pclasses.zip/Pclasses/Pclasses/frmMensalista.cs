﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstMensalista_Click(object sender, EventArgs e)
        {
            //criar obj da classe mensalista

            Mensalista objMensalista = new Mensalista(); //instanciei


            //set

            objMensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntEmpresa.Text); // dd//mm/yyyy
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalMensal.Text);

            //get
            MessageBox.Show("Matricula: " + objMensalista.Matricula + "\n" + 
                "Nome: " +objMensalista.NomeEmpregado + "\n" +
                "Data Entrada: " + objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                "Salario Bruto: " + objMensalista.SalarioBruto().ToString("N2") + "\n" + 
                "Tempo Empresa (dias): " + objMensalista.TempoTrabalho(), "Resultado:",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnInstMensalistaParamentros_Click(object sender, EventArgs e)
        {

            Mensalista objMensalista = new Mensalista(Convert.ToInt32(txtMatricula.Text),
                txtNome.Text, Convert.ToDateTime(txtDataEntEmpresa.Text), Convert.ToDouble(txtSalMensal.Text));

            //get
            MessageBox.Show("Matricula: " + objMensalista.Matricula + "\n" +
                "Nome: " + objMensalista.NomeEmpregado + "\n" +
                "Data Entrada: " + objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                "Salario Bruto: " + objMensalista.SalarioBruto().ToString("N2") + "\n" +
                "Tempo Empresa (dias): " + objMensalista.TempoTrabalho(), "Resultado:", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }
    }
}
