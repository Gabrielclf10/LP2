﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void frmHorista_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInstancHorista_Click(object sender, EventArgs e)
        {
            // nao pode criar obj de classe abstrata
            //criando obj, instanciando o obj
            Horista objHorista = new Horista();

            //set
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNumHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEmpresa.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiasFaltas.Text);

            //get - imprimindo aq os valores do objeto

            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" + "Matrícula: " + objHorista.Matricula + "\n" +
                "Tempo de Trabalho: " + objHorista.TempoTrabalho().ToString() + "\n" + "Salário: R$ " + 
                objHorista.SalarioBruto().ToString("N2"), "Resultado " + MessageBoxButtons.OK + MessageBoxIcon.Information); //personalização bugou



        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
