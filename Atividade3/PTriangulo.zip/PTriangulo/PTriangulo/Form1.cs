﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double LadoA, LadoB, LadoC;

            if (double.TryParse(maskedTextBox1.Text, out LadoA) &&
             double.TryParse(maskedTextBox2.Text, out LadoB) && (double.TryParse(maskedTextBox3.Text, out LadoC)))
            {

                if (((Math.Abs(LadoB - LadoC) < LadoA && LadoA < LadoB + LadoC) && (Math.Abs(LadoA - LadoC) < LadoB && LadoB < LadoA + LadoC)) && (Math.Abs(LadoA - LadoB) < LadoC && LadoC < LadoA + LadoB))
                {

                    if ((LadoA == LadoB) && (LadoB == LadoC))

                        MessageBox.Show("O Triângulo é equilatero","Resultado",MessageBoxButtons.OK, MessageBoxIcon.Information);

                    else if ((LadoA == LadoB || LadoA == LadoC || LadoB == LadoC))

                        MessageBox.Show("O Triângulo é isoceles", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    else
                        MessageBox.Show("O Triângulo é escaleno", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
                else
                    MessageBox.Show("Não é um triângulo!" ,"Resultado", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            maskedTextBox3.Clear();

            maskedTextBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void maskedTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13) 
            {
                SendKeys.Send("{TAB}"); 
                e.Handled = true;   
            }
        }

        private void maskedTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void maskedTextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }
    }
}
