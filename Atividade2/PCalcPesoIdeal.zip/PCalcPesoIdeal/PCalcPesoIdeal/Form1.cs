﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalcPesoIdeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btncalc_Click(object sender, EventArgs e)
        {

            double altura, pesoatual, pesoideal;

            if (double.TryParse(maskedTextBox1.Text, out pesoatual) &&
                double.TryParse(maskedTextBox2.Text, out altura))
            {
                if (radioButton1.Checked == true)
                {
                    pesoideal = (72.7 * altura) - 58;
                    pesoideal = Math.Round(pesoideal, 2);
                    textBox1.Text = pesoideal.ToString();

                    if (pesoatual > pesoideal)
                    {
                        MessageBox.Show("Tu tá gordinho, faça um regime!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else if (pesoatual < pesoideal)
                        MessageBox.Show("Tá magrelo, coma mais!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else
                        MessageBox.Show("UiUiUi, está no peso ideal!!", "Parabéns!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    pesoideal = (62.1 * altura) - 44.7;
                    pesoideal = Math.Round(pesoideal, 2);
                    textBox1.Text = pesoideal.ToString();
                    if (pesoatual > pesoideal)
                    {
                        MessageBox.Show("Está acima do peso ideal, faça um regime!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else if (pesoatual < pesoideal)
                        MessageBox.Show("Está abaixo do seu peso ideal, coma mais!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else
                        MessageBox.Show("UiUiUi, está no peso ideal!!", "Parabéns!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else 
            {
                MessageBox.Show("Informação inserida inválida:  " + maskedTextBox1.Text + maskedTextBox2.Text , " AVISO", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void bntencerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bntlimpar_Click(object sender, EventArgs e)
        {
            maskedTextBox1.Clear();
            maskedTextBox2.Clear();
            textBox1.Clear();

            maskedTextBox1.Focus();

        }

        private void maskedTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13) 
            {
                SendKeys.Send("{TAB}"); 
                e.Handled = true;   
            }
        }

        private void maskedTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
