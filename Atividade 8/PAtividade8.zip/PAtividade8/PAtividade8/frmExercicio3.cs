﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void frmExercicio3_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] quantidade = new int[10];
            double[] preco = new double[10];
            string aux;
            double faturamento = 0;

            for (var i = 0; i < quantidade.Length; i++)
            {
                aux = Interaction.InputBox("Entre com a quantidade do " + (i + 1).ToString() + "° produto", "Entra");

                if (!int.TryParse(aux, out quantidade[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }

            }

            aux = "";

            for (var i = 0; i < quantidade.Length; i++)
            {
                aux = Interaction.InputBox("Entre com o preço do " + (i + 1).ToString() + "° produto", "Entra");

                if (!double.TryParse(aux, out preco[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }

            }

            for (var i = 0; i < 2; i++)
            {
                faturamento += quantidade[i] * preco[i];
                
            }

            MessageBox.Show("Total = " + faturamento.ToString("c"));




        }
    }
}
