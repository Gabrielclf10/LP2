﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[,] vetor = new string[10,3];
            double[,] notas = new double[10, 3];
            double[,] media = new double[10, 1];
            string saida = "";

            int i=0, j=0;


            for (j = 0; j < 3; j++)
                for ( i = 0; i < 10; i++)
                {
                    vetor[i, j] = Interaction.InputBox("Entre com a nota "+ (j+1).ToString() +" do " +(i+1).ToString()+ "º aluno");
                    if ((!double.TryParse(vetor[i,j], out notas[i,j])))
                    {
                        MessageBox.Show("Número inválido");
                        i--;
                    }
                    else if (notas[i, j] > 10)
                    {
                        MessageBox.Show("Número inválido");
                        i--;
                    }
                }

             for (i = 0; i < 10; i++)
             {
                media[i, 0] = ((notas[i, 0]) + (notas[i,1]) + (notas[i,2]))/3;
                saida += "Aluno "+(i+1).ToString() +": média: "+ media[i, 0].ToString("N2" ) + "\n";
       
             }
            
            MessageBox.Show(saida);



        }
    }
}
