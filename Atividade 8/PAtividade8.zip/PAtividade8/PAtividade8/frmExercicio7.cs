﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAtividade8
{
    public partial class frmExercicio7 : Form
    {
        public frmExercicio7()
        {
            InitializeComponent();
        }

        private void frmExercicio7_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int i = 0, qnt = 0;
            string x = "";

            ArrayList Lista = new ArrayList();

            for (i=0; i < 8;i++)
            {
                Lista.Add(Interaction.InputBox("Entre com o " + (i+1).ToString()+ "º nome" ));               
                        
            }
               

            for (i = 0; i < 8; i++)
            {
                x = Lista[i].ToString();
                x = x.Replace(" ", String.Empty);
                qnt = x.Length;
                             
                //MessageBox.Show(Lista[i].ToString() + " contém " + qnt.ToString() + " caractéres."+"\n");
                rchTxt.Text+= "O nome: " + Lista[i].ToString() + " contém " + qnt.ToString() + " caractéres." + "\n";

                qnt = 0;
                x = "";
            }
        }
    }
}
