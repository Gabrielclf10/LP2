﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (var i=0; i<vetor.Length;i++)
            {
                aux = Interaction.InputBox("Entre com o "+(i+1).ToString()+"° número", "Entra");
                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
                //else
                //{
                //    string saida = "";
                //    saida = vetor[i] + saida;

                //}
            }

            aux = "";
            for (var i = vetor.Length - 1; i >= 0; i--)
            {
                aux += vetor[i];

            }
            MessageBox.Show(aux);

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
