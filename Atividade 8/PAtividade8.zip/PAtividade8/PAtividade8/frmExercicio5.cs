﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace PAtividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList();
            Lista.Add("Ana");
            Lista.Add("André");
            Lista.Add("Débora");
            Lista.Add("Fátima");
            Lista.Add("João");
            Lista.Add("Otávio");
            Lista.Add("Marcelo");
            Lista.Add("Pedro");
            Lista.Add("Thais");

            Lista.RemoveAt(5);

            string x = "";

            for (int i=0; i < 8; i++)
            {
                 x += Lista[i].ToString() + "\n";
            }

            MessageBox.Show(x) ;

        }
    }
}
