﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P30482023008
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            //Ultimo digito do meu RA = 8

            double[,] mesSemana = new double[8, 4];
            string x = "";
            double[] totalMes = new double[8];
            double totalGeral = 0;

            for (int i = 0; i < 8; i++)
            {
                for (int k = 0; k < 4; k++)
                {
                    x = Interaction.InputBox("Digite o valor da " + (k + 1).ToString() + "º semana, do " + (i + 1).ToString() + "º mês.");
                 
                    if (x == "")
                    {
                        MessageBox.Show("Insira algum valor", "Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        k--;

                    }

                    else if (!double.TryParse(x, out mesSemana[i, k]))
                    {
                        MessageBox.Show("Apenas números nesse campo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        k--;

                    }
                    else if (double.TryParse(x, out mesSemana[i, k]))
                    {

                    }
                }
                totalMes[i] = mesSemana[i, 0] + mesSemana[i, 1] + mesSemana[i, 2] + mesSemana[i, 3];
            }

            for (int i = 0; i < 8; i++)
            {
                totalGeral += totalMes[i];
            }

            for (int i = 0; i < 8; i++)
            {
                for (int k = 0; k < 4; k++)
                {
                    lbxLista.Items.Add("Total do Mês " + (i + 1).ToString() + " Semana " + (k + 1).ToString() + ": " + mesSemana[i, k].ToString("C2"));
                }
                lbxLista.Items.Add(">> Total Mês: " + totalMes[i].ToString("C2"));
                lbxLista.Items.Add("\n" + "________________________");
            }

            lbxLista.Items.Add(">>> Total Geral: " + totalGeral.ToString("C2"));
            lbxLista.Items.Add("\n" + "////////////////////////////////");
        }
    }
}
